# -#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Author :   Ch
# File    :   __init__.py.py
# @Time   :   2021/1/7 16:48
from practice.models.alex import *
from practice.models.vgg import *
